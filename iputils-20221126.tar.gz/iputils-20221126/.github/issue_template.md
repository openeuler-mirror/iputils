[ type description here; PLEASE REMOVE THIS LINE AND THE LINES BELOW BEFORE SUBMITTING THIS ISSUE ]
<!--
* If reporting a bug, please document how to reproduce it.
* Please always test the latest master branch.
* Finding the commit which introduced the problem helps (bisecting).
* Document the kernel and distribution that were used.
* Tests should ideally use network namespaces to not interfere with the rest of the system.
-->
